package util

import (
	"bytes"
	"database/sql"
	"text/template"

	"github.com/streadway/amqp"

	"github.com/gorilla/sessions"
)

var DB *sql.DB
var Tpl *template.Template
var Store *sessions.CookieStore
var MessageBroker *amqp.Connection
var Network bytes.Buffer
