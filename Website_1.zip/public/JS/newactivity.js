$(function(){
    var ar = ["Sleep", "Running", "Cycling", "Weight","Hydration"]
    
    if ($.inArray($("#inputactivity").val(), arr) == -1){
        alert("Enter a vaalid activity type")
    }

})