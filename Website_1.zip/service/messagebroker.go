package service

import (
	"Website_1/util"
	"bytes"
	"encoding/json"
	"fmt"
	"log"
	"net/http"

	"github.com/streadway/amqp"
)

type Feedback struct {
	Id       string
	Fname    string
	Lname    string
	Email    string
	FeedBack string
}

func MessageBrokerService(w http.ResponseWriter, r *http.Request) {
	//publishing message to the rabbit mq
	if r.Method == "POST" {
		if r.FormValue("feedback") != "" {
			feedbackData := Feedback{
				Id:       r.FormValue("user_id"),
				Fname:    r.FormValue("firstname"),
				Lname:    r.FormValue("lastname"),
				FeedBack: r.FormValue("feedback"),
				Email:    r.FormValue("email"),
			}
			fmt.Println(feedbackData)
			bytedata := new(bytes.Buffer)
			err := json.NewEncoder(bytedata).Encode(feedbackData)
			if err != nil {
				log.Fatal(err)
			}
			ch, err := util.MessageBroker.Channel()
			if err != nil {
				fmt.Println(err)
			}
			defer ch.Close()
			_, err = ch.QueueDeclare("Webapp", false, false, false, false, nil)
			if err != nil {
				fmt.Println(err)
			}

			err = ch.Publish("", "Webapp", false, false, amqp.Publishing{
				ContentType: "text/plain",
				Body:        bytedata.Bytes(),
			})

			if err != nil {
				fmt.Println(err)
			}
			fmt.Println("successfully publish message : ", feedbackData.FeedBack)
		}
		http.Redirect(w, r, "/", 301)
	}
}

func ConsumerService() {
	ch, err := util.MessageBroker.Channel()
	if err != nil {
		fmt.Println(err)
	}
	defer ch.Close()

	message, err := ch.Consume("Webapp", "", true, false, false, false, nil)
	if err != nil {
		log.Fatal(err)
	}
	for d := range message {
		var feedback Feedback
		err := json.Unmarshal(d.Body, &feedback)
		if err != nil {
			fmt.Println(err)
		}
		_, err = util.DB.Exec("INSERT INTO Feedback(Fname, Lname, Email, Feedback, user_id) VALUES($1,$2,$3,$4,$5)",
			feedback.Fname, feedback.Lname, feedback.Email, feedback.FeedBack, feedback.Id)
		if err != nil {
			fmt.Println(err)
			return
		}
		fmt.Println("received message from rabbitmq : ", feedback.FeedBack)
	}
	defer util.MessageBroker.Close()
}
