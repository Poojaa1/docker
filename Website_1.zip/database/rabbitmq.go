package database

import (
	"github.com/streadway/amqp"
)

func StartMessageBroker() *amqp.Connection {
	conn, err := amqp.Dial("amqps://Nitish:Bbnnnsharma@2825@b-464ddd72-8a49-4a04-98a5-533a6665685e.mq.ap-south-1.amazonaws.com:5671")
	if err != nil {
		panic(err)
	}

	return conn
}
